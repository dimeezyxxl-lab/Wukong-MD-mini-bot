/**
 * WhatsApp MD Bot - Main Entry Point
 * Styled for the Great Sage Wukong 🐒⚡
 */
process.env.PUPPETEER_SKIP_DOWNLOAD = 'true';
process.env.PUPPETEER_SKIP_CHROMIUM_DOWNLOAD = 'true';
process.env.PUPPETEER_CACHE_DIR = process.env.PUPPETEER_CACHE_DIR || '/tmp/puppeteer_cache_disabled';

const { initializeTempSystem } = require('./utils/tempManager');
const { startCleanup } = require('./utils/cleanup');
initializeTempSystem();
startCleanup();

// Console overrides for clean logs
const originalConsoleLog = console.log;
const originalConsoleError = console.error;
const originalConsoleWarn = console.warn;

const forbiddenPatternsConsole = [
  'closing session', 'sessionentry', 'prekey bundle', 'ratchet', 'signal protocol'
];

// Helper to suppress noisy internal library logs
const logFilter = (args) => {
  const message = args.map(a => typeof a === 'string' ? a : JSON.stringify(a)).join(' ').toLowerCase();
  return !forbiddenPatternsConsole.some(pattern => message.includes(pattern));
};

console.log = (...args) => logFilter(args) ? originalConsoleLog.apply(console, args) : null;
console.error = (...args) => logFilter(args) ? originalConsoleError.apply(console, args) : null;
console.warn = (...args) => logFilter(args) ? originalConsoleWarn.apply(console, args) : null;

// ... [Keep your existing imports: pino, @whiskeysockets/baileys, etc.] ...

// Main connection function
async function startBot() {
  const sessionFolder = `./${config.sessionName}`;
  const sessionFile = path.join(sessionFolder, 'creds.json');

  // ... [Keep your existing KnightBot session processing logic] ...

  const { state, saveCreds } = await useMultiFileAuthState(sessionFolder);
  const { version } = await fetchLatestBaileysVersion();

  const suppressedLogger = createSuppressedLogger('silent');

  const sock = makeWASocket({
    version,
    logger: suppressedLogger,
    printQRInTerminal: false,
    browser: ['Wukong-MD', 'Chrome', '10.0'],
    auth: state,
    syncFullHistory: false,
    downloadHistory: false,
    markOnlineOnConnect: false,
    getMessage: async () => undefined
  });

  store.bind(sock.ev);

  sock.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect, qr } = update;

    if (qr) {
      console.log('\n🐒 *The Great Sage requires your scan:*');
      qrcode.generate(qr, { small: true });
    }

    if (connection === 'open') {
      console.log('\n✅ *The Celestial Gates have opened!*');
      console.log(`📱 *Bot Identity:* ${sock.user.id.split(':')[0]}`);
      console.log(`🤖 *Bot Name:* ${config.botName}`);
      console.log(`👑 *Architect:* XyzTech`);
      console.log(`⚡ *Power Level (Prefix):* ${config.prefix}\n`);
      
      if (config.autoBio) {
        await sock.updateProfileStatus(`${config.botName} | Powered by XyzTech | Active 24/7`);
      }
      handler.initializeAntiCall(sock);
    }
    // ... [Keep your existing connection close/reconnect logic] ...
  });

  // ... [Keep your message handler logic] ...
}

// Start the bot with Monkey King Flair
console.log('🚀 *Wukong MD is awakening...*');
console.log('------------------------------------');
console.log(`📦 Bot Name: ${config.botName}`);
console.log(`👑 Mastermind: XyzTech`);
console.log(`⚡ Prefix: ${config.prefix}`);
console.log('------------------------------------\n');

cleanupPuppeteerCache();

startBot().catch(err => {
  console.error('💥 *The heavens have collapsed during startup:*', err);
  process.exit(1);
});

// ... [Keep your error handling logic] ...
